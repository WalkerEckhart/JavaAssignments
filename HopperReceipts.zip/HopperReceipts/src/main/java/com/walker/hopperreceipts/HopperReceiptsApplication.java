package com.walker.hopperreceipts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopperReceiptsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HopperReceiptsApplication.class, args);
	}

}
