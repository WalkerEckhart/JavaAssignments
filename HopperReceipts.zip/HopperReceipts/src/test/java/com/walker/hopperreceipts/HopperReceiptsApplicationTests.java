package com.walker.hopperreceipts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HopperReceiptsApplicationTests {

	@Test
	void contextLoads() {
	}

}
