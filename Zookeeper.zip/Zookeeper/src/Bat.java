
public class Bat extends Mammal{

	public void fly(int times) {
		energy -= times * 50;
		System.out.printf("The dude is airborne!\nBat's energy: %d\n", energy);
	}
	public void eatHumans(int humans) {
		energy =+ humans * 50;
		System.out.printf("Hope it wasn't your grandma!\nBat's energy: %d\n", energy);
	}
	public void attackTown(int towns) {
		energy -= towns * 100;
		System.out.printf("NOT THE WALGREENS!!!!!\nBat's energy: %d\n", energy);
	}
}
