
public class Mammal {

	public String name;
	public double weight;
	public boolean fly;
	public int energy;
	public String diet;
	boolean hasEnergy = true;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}

	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	public String getDiet() {
		return diet;
	}
	public void setDiet(String diet) {
		this.diet = diet;
	}
	
	public void displayEnergy(int energy) {
		this.energy = energy;
		if (energy <= 0) {
			energy = 0;
			this.hasEnergy = false;
			System.out.println("This animal has no energy!");
		}
		System.out.println(energy);
	}
	public boolean getHasEnergy(boolean hasEnergy) {
		return this.hasEnergy;
	}
}
