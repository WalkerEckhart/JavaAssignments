
public class MammalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla G = new Gorilla();
		
		G.setEnergy(100);
		G.throwSomething(3);
		G.eatBanana(2);
		G.climb(1);
		
		Bat B = new Bat();
		B.setEnergy(300);
		B.eatHumans(8);
		B.fly(2);
		B.attackTown(2);
	}

}
