
public class Gorilla extends Mammal {

	public void throwSomething(int times) {
		this.hasEnergy = super.getHasEnergy(hasEnergy);
		if (hasEnergy == true) {
		energy -= times * 5;
		System.out.printf("Uh oh! Someone threw a stinky!\nGorilla's energy: %d\n", energy);
		} else {
			super.displayEnergy(energy);
		}
	}
	public void eatBanana(int bananas) {
		energy = super.getEnergy();
		energy += bananas * 10;
		System.out.printf("MMMMMMMMM banana\nGorilla's energy: %d\n", energy);
	}
	public void climb(int times) {
		energy = super.getEnergy();
		energy -= times * 10;
		System.out.printf("\nCLIMBCLIMBCLIMBCLIMBCLIMB\nGorilla's energy: %d\n", energy);
	}
}
