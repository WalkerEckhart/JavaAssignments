import java.util.Date;
import java.util.ArrayList;

class CafeUtil {
    public int getStreakGoal(int num) {
        int numWeeks = num;
        int sum = 0;
        for (int i = 0; i < numWeeks; i++ ) {
            sum += i;
        } return sum;
    }
    public double getOrderTotal(double[] lineItems) {
        double totalPrice = 0.0;
        for (int i = 0; i < lineItems.length - 1; i++) {
            totalPrice += lineItems[i];
        } return totalPrice;
    } 
    public void displayMenu(ArrayList<String> menuItems) {
        for (int i = 0; i < menuItems.size(); i++) {
            System.out.printf("%s %s \n", i, menuItems.get(i));
        }
    }
    public void addCustomer(ArrayList<String> customers) {
        System.out.println("Please enter your name or type 'Exit' to cancel:");
            String customer = System.console().readLine();
        if (customer.equals("exit") || customer.equals("Exit")) {
            return; 
        } else {
        customers.add(customer);
        int position = customers.size() - 1;
            System.out.printf("Hello," + customer + "!");
            System.out.printf("\nThere are" + " " + position + " " + "people in front of you. :(");
        }
    }
}
