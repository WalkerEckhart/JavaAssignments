public class BankAccount {
    // MEMBER VARIABLES
	private String accountName;
    private double checkingBalance;
    private double savingsBalance;
    public static int accounts;
    public static double totalMoney = 0.0; 
    public static int numberOfPeople = 0;// refers to the sum of all bank account checking and savings balances
    // CONSTRUCTOR
    public BankAccount() {
    	BankAccount.numberOfPeople += 1;
    	this.checkingBalance = 0.0;
    	this.savingsBalance = 0.0;
    	
    		}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public double getCheckingBalance() {
		return checkingBalance;
	}
	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}
	public static double getTotalMoney() {
		return totalMoney;
	}
	public static void setTotalMoney(double totalMoney) {
		BankAccount.totalMoney = totalMoney;
	}
	public double getSavingsBalance() {
		return savingsBalance;
	}
	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}
    

//Done     GETTERS
    // for checking, savings, accounts, and totalMoney
    // METHODS
    // deposit
public void depositMoney(String account, double value) {
	if (account.equals("savings")) {
		this.savingsBalance += value;
		BankAccount.totalMoney += value;
	} else if (account.equals("checking")) {
		this.checkingBalance += value;
		BankAccount.totalMoney += value;
	}
}


    // - users should be able to deposit money into their checking or savings account
    // withdraw 
public void withdrawMoney(String account, double value) {
	boolean canWithdraw = false;
	if (account.equals("savings")) {
		if (this.savingsBalance - value >= 0) {
			canWithdraw = true;
			this.savingsBalance -= value;
			BankAccount.totalMoney -= value;
	} else {
		System.out.printf("You cannot withdraw $.2f because your account balance is %.2f", value, this.savingsBalance);
	} if (account.equals("checking")) {
		if (this.checkingBalance - value >= 0) {
			canWithdraw = true;
			this.checkingBalance -= value;
			BankAccount.totalMoney -= value;
	} else {
		System.out.printf("You cannot withdraw $.2f because your account balance is %.2f", value, this.checkingBalance);

	
	}
}
}
}
}

    // - users should be able to withdraw money from their checking or savings account
    // - do not allow them to withdraw money if there are insufficient funds
    // - all deposits and withdrawals should affect totalMoney
    // getBalance
    // - display total balance for checking and savings of a particular bank account

