public class BankTest {
    public static void main(String[] args){
//DONE        Create 3 bank accounts
    	BankAccount user1 = new BankAccount();

    	System.out.println(user1.getCheckingBalance());
    	System.out.println(user1.getSavingsBalance());
    	

        // Deposit Test
        // - deposit some money into each bank account's checking or savings account and display the balance each time
    	user1.depositMoney("checking", 45.2);
    	user1.depositMoney("savings", 10000);
        // - each deposit should increase the amount of totalMoney
        // Withdrawal Test
    	user1.withdrawMoney("savings", 10.0);
        // - withdraw some money from each bank account's checking or savings account and display the remaining balance
        // - each withdrawal should decrease the amount of totalMoney
        // Static Test (print the number of bank accounts and the totalMoney)
    	System.out.println(BankAccount.numberOfPeople);
    	System.out.println(BankAccount.totalMoney);
    }


}
