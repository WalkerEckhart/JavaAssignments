public class me {
    public static void main(String[] args) {
        System.out.println("My name is Walker E");
        System.out.println("I am 21 years old");
        System.out.println("My homestate is Maryland");
    }
}
