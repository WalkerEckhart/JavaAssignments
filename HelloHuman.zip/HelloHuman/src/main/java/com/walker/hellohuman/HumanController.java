package com.walker.hellohuman;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HumanController {
	@RequestMapping("/")
	public String greeting(@RequestParam(value="f", required=false) String firstName, @RequestParam(value="l", required=false) String lastName, @RequestParam(value="times", required=false) Integer times) {
		if (firstName == null && lastName == null) {
			return "Welcome, who I assume to be Clint Eastwood.";
		} else {
			StringBuilder greetings = new StringBuilder();
	        for (int i = 0; i < times; i++) {
	            greetings.append("Howdy, ").append(firstName).append(" ").append(lastName).append("\n");
	        }
	        return greetings.toString();
	    }
}
}
